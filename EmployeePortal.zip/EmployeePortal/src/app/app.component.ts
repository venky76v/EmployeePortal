import { Component } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { EmployseeService } from './core/employee.service';
import { HttpErrorResponse } from '@angular/common/http';
import { ValidationError } from './models/validationError';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})

export class AppComponent {
  title = 'Employee Portal';
  saving = false;
  employeeForm = new FormGroup({
    FirstName: new FormControl(''),
    LastName: new FormControl(''),
    DateOfBirth: new FormControl(''),
    PhoneNumber: new FormControl(''),
    Email: new FormControl(''),
    NumberOfYearsOfExperience: new FormControl('')
  });

  constructor(private employeeService: EmployseeService) {}

  onSubmit(value) {
    const formValue = value.getRawValue();
    let index: number = 0;
    let errorFromServer = String;
    let validationErrorsArray: any;
    let businessValidationError: ValidationError;

    this.employeeService.create(formValue).subscribe(x => {
      console.log('something happened');
    }, (err: HttpErrorResponse) => {
      if (err instanceof Error) {
        console.log(`An error occurred ${err.error.message}`);
      } else {
        switch (err.status) {
          case 400:
          validationErrorsArray = Object.values(err.error)[0];
          Object.keys(validationErrorsArray).forEach(prop => {
            errorFromServer = Object.values(validationErrorsArray)[index];
            const formControl = this.employeeForm.get(prop);
            if (formControl) {
              formControl.setErrors({
                serverError: errorFromServer
              });
            }
            index++;
          });
          break;
          case 422:
          validationErrorsArray = Object.values(err.error)[3];
          Object.values(validationErrorsArray).forEach(prop => {
            businessValidationError = prop;
            const formControl = this.employeeForm.get(businessValidationError.field);
            if (formControl) {
               formControl.setErrors({
                 serverError: businessValidationError.message
               });
           }
          });
          break;
        }
      }
    });
  }
}
