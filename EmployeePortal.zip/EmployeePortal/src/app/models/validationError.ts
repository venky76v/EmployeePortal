export interface ValidationError {
    field: string;
    message: string;
}
