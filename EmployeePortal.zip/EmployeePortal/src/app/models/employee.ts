export interface Employee {
    firstName: string;
    lastName: string;
    dateOfBirth: string;
    phoneNumber: string;
    email: string;
    numberOfYearsOfExperience: number;
}

