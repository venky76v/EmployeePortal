import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Employee } from '../models/employee';


@Injectable({
    providedIn: 'root'
})

export class EmployseeService {
    API_URL = 'http://localhost:63497/api/employee';
    constructor(private http: HttpClient) {}

    create(employee: Employee) {
        return this.http.post<Employee>(this.API_URL, employee);
    }
}
