﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EmployeeAPI.Models
{
    public class Employee
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long EmployeeId { get; set; }
        [Required(ErrorMessage ="First name is mandatory")]
        [MaxLength(50, ErrorMessage = "First name cannot be greater than 50")]
        public string FirstName { get; set; }
        [Required(ErrorMessage = "Last name is mandatory")]
        [MaxLength(50, ErrorMessage = "Last name cannot be greater than 50")]
        public string LastName { get; set; }
        [Required(ErrorMessage = "Date of birth is mandatory")]
        public DateTime DateOfBirth { get; set; }
        [Required(ErrorMessage = "Phone number is mandatory")]
        [MaxLength(10)]
        public string PhoneNumber { get; set; }
        [Required(ErrorMessage = "Email address is mandatory")]
        [EmailAddress(ErrorMessage = "Invalid Email Address")]
        public string Email { get; set; }
        [Required(ErrorMessage = "You need to have some work experience")]
        public int NumberOfYearsOfExperience { get; set; }

        public static IDictionary<string, string> ValidateBusinessRulesEmployee(Employee employee)
        {
            var today = DateTime.Today;
            Dictionary<string, string> validationErrors = new Dictionary<string, string>();
            var age = today.Year - employee.DateOfBirth.Year;
            if (employee.DateOfBirth > today.AddYears(-age)) age--;

            if (age < MIN_EMPLOYEE_AGE)
            {
                validationErrors.Add(nameof(employee.DateOfBirth), "Too young to start work, wait till you get past your teens");
            } 
            else if (age > MAX_EMPLOYEE_AGE)
            {
                validationErrors.Add(nameof(employee.DateOfBirth), "You are too old to work with us. We can't you take in our team");
            }

            if (employee.NumberOfYearsOfExperience < MIN_EMPLOYEE_EXPERIENCE_NEEDED)
            {
                validationErrors.Add(nameof(employee.NumberOfYearsOfExperience), "Too inexperienced to work with us, look somewhere else for work");
            }
            else if (employee.NumberOfYearsOfExperience > MAX_EMPLOYEE_EXPERIENCE_ALLOWED)
            {
                validationErrors.Add(nameof(employee.NumberOfYearsOfExperience), "You are over qualified to work with us, look somewhere else for work");
            }

            return validationErrors;
        }

        #region BUSINESS_CONSTANTS
        const int MIN_EMPLOYEE_AGE = 17;
        const int MAX_EMPLOYEE_AGE = 60;
        const int MIN_EMPLOYEE_EXPERIENCE_NEEDED = 3;
        const int MAX_EMPLOYEE_EXPERIENCE_ALLOWED = 10;

        #endregion
    }
}
