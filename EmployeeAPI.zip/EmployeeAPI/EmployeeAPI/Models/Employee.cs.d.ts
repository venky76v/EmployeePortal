declare module server {
	interface employee {
		employeeId: number;
		firstName: string;
		lastName: string;
		dateOfBirth: Date;
		phoneNumber: string;
		email: string;
		numberOfYearsOfExperience: number;
	}
}
