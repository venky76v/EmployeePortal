﻿using Microsoft.AspNetCore.Mvc.ModelBinding;
using System;
using System.Collections.Generic;
using System.Linq;

namespace EmployeeAPI.Utilities
{
    public class ValidationResultModel
    {
        public string title { get; }
        public int status { get; set; }
        public string traceId { get; set; }

        public List<ValidationError> Errors { get; }

        public ValidationResultModel(ModelStateDictionary modelState, int statusCode)
        {
            title = "Validation Failed";
            status = statusCode;
            traceId = Guid.NewGuid().ToString();
            Errors = modelState.Keys
                    .SelectMany(key => modelState[key].Errors.Select(x => new ValidationError(key, x.ErrorMessage)))
                    .ToList();
        }
    }
}
