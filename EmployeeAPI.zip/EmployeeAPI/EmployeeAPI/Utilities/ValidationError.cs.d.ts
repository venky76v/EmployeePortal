declare module server {
	interface validationError {
		field: string;
		message: string;
	}
}
